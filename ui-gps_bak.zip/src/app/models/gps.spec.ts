import { Gps } from './gps';

describe('Gps', () => {
  it('should create an instance', () => {
    expect(new Gps()).toBeTruthy();
  });
});
