export class Gps {
    servicos: Array<String>;
    especiais: Array<String>;
    lugar: Array<String>;
    mapa: Array<String>;
    nome: String;
    telefone: String;
    dataCadastro: String;
}
